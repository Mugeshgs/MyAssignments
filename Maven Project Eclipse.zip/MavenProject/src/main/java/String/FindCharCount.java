package String;

public class FindCharCount {

	public static void main(String[] args) {

		int count=-1;
		int first=0,second=first+1;

String s="Testleaf";

char[] ch= s.toCharArray();

for(first=0;first<ch.length;first++) {
	
	for(second=first+1;second<ch.length;second++) { 
		
	if(ch[first]==ch[second]) {
		
		count++;
		
	}

}
	System.out.println(count);


	}

}}
