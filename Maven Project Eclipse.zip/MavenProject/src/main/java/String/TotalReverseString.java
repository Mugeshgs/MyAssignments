
package String;

public class TotalReverseString {

	public static void main(String[] args) {

		String amazon="Amazon development centre, Chennai";
		
		//String  input=“Amazon development centre, Chennai"; 
		//Output = chennai,centre development amazon
		//Goal: To understand String , loopa)Convert the string to lower case
		//b)split the sentence with white space and get the count of the words
		//c)Use for loop to iterate (from end to go to the first)
		//d)Print the  reversed String
		//*Hint  Use system.out.print()

		
		String lowercase=amazon.toLowerCase();
		String[] split = lowercase.split(lowercase);
		
		for(int i=split.length-1;i>=0;i--) 
		{
			if(i%2==0) {
			System.out.println(split[i]);
		}
		}
	}

}
