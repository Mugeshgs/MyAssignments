package String;

public class LearnString {

	public static void main(String[] args) {

		//String Literals
		String S1="Testleaf";
		String S2="TestLeaf";
		
		//String Instantiate (object)
		
		String str=new String("Testleaf");
		
		System.out.println(S1.equals(S2));
		System.out.println(S1.equalsIgnoreCase(S2));
		
		//== Compare reference memory 
		System.out.println(S1==str);
		
		int length=S1.length();
		System.out.println(length);
		
		int length1=str.length();
		System.out.println(length1);
		
		//contains
		
		System.out.println("Contains F? "+ S1.contains("F"));
		
		//To return the string as an each characters, convert the string into an Array
		
	
		
	
		
		
		
		
	}

}
