package String;

public class StringPractice {

	public static void main(String[] args) {
	
		String s= "We learn java basics as part of java sessions in java week1";
		
		String [] duplicate=s.split(" ");
		int count;
		
		for(int i=0;i<=duplicate.length;i++) {
			
			count=1;
			
			//to avoid iterating the already searched string in the array
			
			if(duplicate[i]!="0"){
				
			
			for(int j=i+1;j<duplicate.length;j++) {
				
				if(duplicate[i].equals(duplicate[j])) {
					count++;
					duplicate[j]="";
				}
				
			}
			}
			
			if(count==1) {
				System.out.println(duplicate[i]);
				
			}
			
			
		}
		
		
		
		
	}}