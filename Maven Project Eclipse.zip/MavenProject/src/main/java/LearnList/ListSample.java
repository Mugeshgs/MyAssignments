package LearnList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.testng.annotations.Test;

public class ListSample {
@Test
	public void ListTestNG() {

		List <Integer> lst=new ArrayList<Integer>();
		
		lst.add(1);
		lst.add(0);
		lst.add(2);

		lst.add(4);

		lst.add(10);

		lst.add(100);

		System.out.println(lst);
		Collections.sort(lst);
		System.out.println("Sorting:"+lst);
		
	//Literal
	String s1="This is a Sample String Code";
	String s2="This is a Sample String Code2";
	
	//Instantiate
	String str=new String("This is a Sample String Code2");

	System.out.println(s1.equals(s2));
	System.out.println(s1.equals(str)); //Literal and Instantiate are different 
	
char [] ch=s1.toCharArray();	

//for(int i=0;i<ch.length;i++) {
//	
//	System.out.print(ch[i]);
//}

for(int i=ch.length-1;i>=0;i--) {
	System.out.print(ch[i]);
}
	


	}

}
