package interfaceandabstractclass;

public abstract class MultipleLangauge {

		public void python() {
			
		}
		
		public abstract  void ruby();
}
