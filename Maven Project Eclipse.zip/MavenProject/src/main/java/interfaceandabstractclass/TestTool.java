package interfaceandabstractclass;

public interface TestTool {
public void Selenium();
}
