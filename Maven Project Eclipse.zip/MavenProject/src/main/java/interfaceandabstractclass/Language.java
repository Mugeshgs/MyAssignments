package interfaceandabstractclass;

public interface Language {
	
	public void Java();

}
