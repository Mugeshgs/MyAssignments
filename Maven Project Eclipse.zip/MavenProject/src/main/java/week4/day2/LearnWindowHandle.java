package week4.day2;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearnWindowHandle
{

	public static void main(String[] args) throws InterruptedException 
	{

		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.irctc.co.in/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	
		driver.findElement(By.xpath("//a[text()=' FLIGHTS ']")).click();
		//Title of the Old tab
		System.out.println(driver.getTitle());
		
		Set<String> windowHandles = driver.getWindowHandles();
		
		List<String>lstWindow =new ArrayList<String>(windowHandles);
 
		driver.switchTo().window(lstWindow.get(1));

		System.out.println(driver.getTitle());

		driver.switchTo().window(lstWindow.get(0));

		driver.close();


//		//Multiple window
//		Set<String> windowHandles = driver.getWindowHandles();
//		//create a list then convert set into
//		List<String>lstwindow =new ArrayList<String>(windowHandles);
//		//handle the window
//		driver.switchTo().window(lstwindow.get(1));
//		//get the size of window
//		System.out.println(windowHandles.size());
//		//print the title
//		System.out.println(driver.getTitle());
//		//close the current open window
//		driver.close();

	}

}
