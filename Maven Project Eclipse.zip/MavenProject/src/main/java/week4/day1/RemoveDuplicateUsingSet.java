package week4.day1;

import java.util.LinkedHashSet;
import java.util.Set;

public class RemoveDuplicateUsingSet {

	public static void main(String[] args) {


		String input="Testleaf";
		
		//convert the string into an array
		
		char[] charArray = input.toCharArray();
		
		Set <Character> unique=new LinkedHashSet<Character>();
		
		for (Character character : charArray) {
			
			  
			
		}
	}

}
