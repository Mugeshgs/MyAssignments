package week4.day1;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class LearnSet {

	public static void main(String[] args) {
		
Set <String> company=new LinkedHashSet<String>(); // As per the insertion order
//Set <String> company=new HashSet<String>(); ---Random order
//Set <String> company=new TreeSet<String>(); --- Alphabetical Order


company.add("Zoho");
company.add("Analytics");
company.add("Freshworks");
company.add("Zuper");
company.add("Accenture");

System.out.println(company);
System.out.println(company.size());
System.out.println(company.contains("Zoho"));
System.out.println(company.toArray());
System.out.println(company);

//FOR LOOP IS NOT POSSIBLE. INSTEAD USE FOR..EACH LOOP

System.out.println("------------------------------------");

for (String str : company) {
	System.out.println(str);
	
	
	
}
	}

}


