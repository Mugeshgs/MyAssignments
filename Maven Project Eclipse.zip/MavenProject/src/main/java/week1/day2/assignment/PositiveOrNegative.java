package week1.day2.assignment;

public class PositiveOrNegative {

	public static void main(String[] args) {

		int a=35;
		if(a>0) {
			System.out.println("The number is Positive");
		}
		else if(a<0) {
			
			System.out.println("The number is Negative");
		}
		else {
			System.out.println("The number is neither Positive nor Negative");
		}
	}

}

