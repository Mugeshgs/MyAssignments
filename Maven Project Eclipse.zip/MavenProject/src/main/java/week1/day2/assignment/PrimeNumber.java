package week1.day2.assignment;

public class PrimeNumber {
	
	public static void main(String args[] ){
		
		int output=13;
		
		for(int i=1;i<=13;i++) {
			
			if(i%output==0) {
				System.out.println(output + "is a Prime Number");
				
			}
		}
		
	}

}
