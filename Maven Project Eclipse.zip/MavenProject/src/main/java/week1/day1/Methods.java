package week1.day1;

public class Methods {
	
	public int OddorEven(int a,int b) 
	{
	int c=a+b;
		System.out.println(c);
		return c;
	}
	
	public static void main(String args[]) {
		
		Methods m=new Methods(); 
		m.OddorEven(20,30);
		
		
	}

}
