package week1.day1.assignment;

public class Browser {
	
	public static void main(String args[]) {
		
		System.out.println("This is My Browser");
		
	}

}
