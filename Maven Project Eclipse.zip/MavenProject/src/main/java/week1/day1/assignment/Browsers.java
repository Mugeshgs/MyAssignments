package week1.day1.assignment;

public class Browsers {
	
	public static void main (String args[]) {
		
		Chrome c=new Chrome();
		c.getname();
		c.printname();
		
		
	}

}
