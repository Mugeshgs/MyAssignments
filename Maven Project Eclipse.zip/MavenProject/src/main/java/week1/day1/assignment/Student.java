package week1.day1.assignment;


public class Student {
	
	String studentName;
	int rollNo;
	String collegeName;
	double markScored;
	double cgpa;
	
	
	

}
