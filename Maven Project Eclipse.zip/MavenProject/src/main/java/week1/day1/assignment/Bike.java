package week1.day1.assignment;

public class Bike {
	
	public static void main(String args[]) {
		
		Car c=new Car();
		/*Bike b=new Bike();*/
		
		c.applyBreak();
		c.soundHorn();
	}

}
