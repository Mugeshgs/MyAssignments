package week1.day1.assignment;

public class Chrome {

	public void getname() {
		
	}
	public void printname() {
		
	System.out.println("Tihs is Google Chrome");
	
	}
	}
