package LearnActions;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class MouseHoverAction {

	public static void main(String[] args) {
		
		
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys("Phones", Keys.ENTER);
		driver.findElement(By.xpath("(//span[@class='a-size-medium a-color-base a-text-normal'])[1]")).click();
		
		Set<String> windowhandles=driver.getWindowHandles();
		
		List<String> lst=new ArrayList<String>(windowhandles);
		driver.switchTo().window(lst.get(1));
		
	/**	//HoverAction
		//1st step: Locate the web element
		
		WebElement mouseHover = driver.findElement(By.xpath("(//a[text()='makeup'])[2]"));
		
		//2nd Create an object for action class
		
		Actions builder=new Actions(driver);
		builder.moveToElement(mouseHover).perform();
		*/
		
		WebElement scroll = driver.findElement(By.xpath("(//span[text()='About this item'])[1]"));
		
		Actions builder1=new Actions(driver);
		
		builder1.scrollToElement(scroll).perform();
	}

}
