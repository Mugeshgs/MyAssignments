package JavaChallenges;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PalindromeChallenge {

	public static void main(String[] args) {

		
		String str="A man, a plan, a canal: Panama";
		
String lowerCase = str.toLowerCase();
String replaced = lowerCase.replaceAll("[^a-zA-Z0-9]","");

char[] charArray = replaced.toCharArray();
String stock="";

for(int i=charArray.length-1;i>=0;i--) {
	
	stock=stock+charArray[i];
	
		
}

System.out.print(stock);

if(stock.equals(replaced)) {
	System.out.println("Palindrome");
}
else {
	System.out.println("Not a palindrome");
}

//String replaced = lowerCase.replaceAll("[a-zA-Z]", "");
//
//
//System.out.println(replaced);
//Pattern p=Pattern.compile("[a-zA-Z]");
//Matcher m=p.matcher(lowerCase);





}

}
