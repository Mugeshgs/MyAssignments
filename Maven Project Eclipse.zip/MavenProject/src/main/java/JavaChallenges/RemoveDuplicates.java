package JavaChallenges;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class RemoveDuplicates {

	public static void main(String[] args) {

		
//				Declare a String as "PayPal India"
		
		String s= "PayPal India";

//				Convert it into a character array
		
		char[] ch = s.toCharArray();
		System.out.println(ch);


//				Declare a Set as charSet for Character
		
		Set<Character> charSet=new LinkedHashSet<Character>();

//				Declare a Set as dupCharSet for duplicate Character
		
		Set<Character> dupCharSet =new LinkedHashSet<Character>();

//				Iterate character array and add it into charSet
		
		for(int i=0;i<ch.length;i++) {
		
			boolean add = charSet.add(ch[i]);
			
	if(add==false) {
		
		boolean add2 = dupCharSet.add(ch[i]);
				
			}
		}

//				if the character is already in the charSet then, add it to the dupCharSet
		
	System.out.println(charSet);
	System.out.println(dupCharSet);
			
			
		}

//				Check the dupCharSet elements and remove those in the charSet

//				Iterate using charSet

//				Check the iterator variable isn't equals to an empty space

//				print it

			}

		
	


