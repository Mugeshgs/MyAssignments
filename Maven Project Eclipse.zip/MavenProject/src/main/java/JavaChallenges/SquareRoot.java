package JavaChallenges;

public class SquareRoot {

	public static void main(String[] args) {

int num=49;
int i=2;

//n=num/n

while(i<num/2) {
	
	if(num/i==i) {
		System.out.println("Square root of "+num+ " is: " +i);
		break;
	}
	i++;
}

	}

}
