package week2.day2;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumSample1 {

	public static void main(String[] args) throws InterruptedException {

		
		ChromeDriver driver=new ChromeDriver();
		
		driver.get("https://dev31913.service-now.com/");
		
		driver.manage().window().maximize();
		
	driver.findElement(By.id("user_name")).sendKeys("admin");
		
		Thread.sleep(2000);
		
		//findElement Enter password
		
		driver.findElement(By.id("user_password")).sendKeys("q+NozS5Qe8!E");
		
		//findElement click login
		
		driver.findElement(By.id("sysverb_login")).click();

		Thread.sleep(2000);
	}

}
