package week2.day2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DropDownClassRoom {

	public static void main(String[] args) throws InterruptedException {
																														/*	1. Launch http://leaftaps.com/opentaps
																																2. Enter username as demoSalesManager
																																3. Enter password as crmsfa
																																4. Click on Login
																																5. Click on CRM/SFA
																																6. Click on Leads
																																7.Click on Create lead
																																8. Enter the mandatory fields
																																9. Select Employee in source dropdown using index
																																10.Click create
																																11.Verify the title*/
		ChromeDriver driver =new ChromeDriver();
		driver.get("http://leaftaps.com/opentaps");
		driver.manage().window().maximize();
		
	driver.findElement(By.id("username")).sendKeys("demoSalesManager");
		
		Thread.sleep(2000);
		
		
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		
		
		driver.findElement(By.className("decorativeSubmit")).click();
		
		 driver.findElement(By.linkText("CRM/SFA")).click();
			
	     driver.findElement(By.linkText("Leads")).click();
	     
	     driver.findElement(By.partialLinkText("Create")).click();
	     
	     driver.findElement(By.id("createLeadForm_companyName")).sendKeys("Zoho");
	     
	     // Enter FirstName
	     driver.findElement(By.id("createLeadForm_firstName")).sendKeys("Mugesh");
	     
	     //Enter Lastname
	     
	     driver.findElement(By.id("createLeadForm_lastName")).sendKeys("Raja");
	     
	     //Click CreateLead Button
         driver.findElement(By.name("submitButton")).click();
         //verify my created or not
	     //Locating the drop down element
	     
	    WebElement tools= driver.findElement(By.className("industryEnumId"));
	     
	     //instantiate the class
	    
	    Select drop1=new Select(tools);
	    
	    drop1.selectByIndex(3);
	     		
	    String title = driver.getTitle();    
		
		System.out.println(title);
	}

}
