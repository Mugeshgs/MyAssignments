package week2.day1;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class SalesForceLoginAutomation {

	public static void main(String[] args) throws InterruptedException {

		ChromeDriver driver =new ChromeDriver();
		//Load the url
		
		driver.get("https://login.salesforce.com/");
		//maximize the window
		
		driver.manage().window().maximize();
	
		//findElement Enter username
		
		driver.findElement(By.id("username")).sendKeys("hari.radhakrishnan@qeagle.com");
		
		Thread.sleep(2000);
		
		//findElement Enter password
		
		driver.findElement(By.id("password")).sendKeys("Leaf$1234");
		
		//findElement click login
		
		driver.findElement(By.id("Login")).click();

		Thread.sleep(2000);
		
		String title = driver.getTitle();  
	//assign local variable ctrl+2
		System.out.println(title);
	}

}
