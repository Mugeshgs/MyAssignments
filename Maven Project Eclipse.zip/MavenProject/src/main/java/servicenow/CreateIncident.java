package servicenow;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.sukgu.Shadow;

public class CreateIncident {
	
	/**Assignment- Service now Application
	================================
	1.Create new incident
	1. Launch ServiceNow application
	2. Login with valid credentials (refer the document to create the instance)
	3. Click All and enter Incident in filter navigator and press enter
	4. Click on Create new option and fill the mandatory fields
	5. Verify the newly created incident ( copy the incident number and paste it in search field and enter then verify the instance number created or not)
	**************
*/

	public static void main(String[] args) {

ChromeDriver driver=new ChromeDriver();
driver.get("https://dev104098.service-now.com/navpage.do");
driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
driver.findElement(By.id("user_name")).sendKeys("admin");
driver.findElement(By.id("user_password")).sendKeys("t$q3/yzMN3CQ",Keys.ENTER);

//Shadow DOM

Shadow shadow=new Shadow(driver);




	}

}
