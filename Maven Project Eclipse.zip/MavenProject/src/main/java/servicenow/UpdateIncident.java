package servicenow;

/*
 * 2.Update existing incident
	====================
	1. Launch ServiceNow application
	2. Login with valid credentials 
	3. Click All and enter Incident in filter navigator and press enter
	4. Search for the existing incident and click on the incident
	5. Update the incidents with Urgency as High and State as In Progress
	6. Verify the priority and state 
	****************
 */
public class UpdateIncident {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
