package ListSetMap;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AmazonPrice {

	public static void main(String[] args) {

		ChromeDriver driver = new ChromeDriver();

		driver.get("https://www.amazon.in/");

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

		driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys("mobiles", Keys.ENTER);
		List<WebElement> priceList = driver.findElements(By.className("a-price-whole"));
		
		List<Integer> sortedPriceList = new ArrayList<Integer>();
		
		//converting into integer
		
for(int i=0;i<priceList.size();i++) {
	
	String text=priceList.get(i).getText();
	String replaceText=text.replaceAll("[^0-9]", "");
	
	int n=Integer.parseInt(replaceText);
	
	sortedPriceList.add(n);
}

Collections.sort(sortedPriceList);

System.out.println(sortedPriceList);
System.out.println("Lowest Price :"+sortedPriceList.get(0));
System.out.println("Highest Price :"+sortedPriceList.get(sortedPriceList.size()-1));
		

	}

}
