package ListSetMap;

import java.util.ArrayList;
import java.util.List;

public class HowListWorks {

	public static void main(String[] args) {

		List<String> lst=new ArrayList<String>();
		
		lst.add("A");
		lst.add("B");
		lst.add("a");
		lst.add("C");
		lst.add("b");
		
		//iterating the List using FOR..EACH loop
		for(String str:lst) {
			System.out.println(str);

		}
		
	}

}
