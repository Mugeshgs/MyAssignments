package ListSetMap;

import java.util.HashMap;
import java.util.Map;

public class HowMapWorks {

	@SuppressWarnings("removal")
	public static void main(String[] args) {
		
		Map<String, Integer> map=new HashMap<String, Integer>();
		
		map.put("Mugesh", new Integer(100));
		map.put("GS", new Integer(200));
		
	System.out.println(map);	
		
	}

}
