package ListSetMap;

import java.util.Set;
import java.util.HashSet;

public class HowSetWorks {

	public static void main(String[] args) {

		Set<String> setstr=new HashSet<String>(); 
		
		setstr.add("A");
		setstr.add("B");
		setstr.add("C");
		setstr.add("a");
		setstr.add("A");
		setstr.add("AD");
		setstr.add("c");
		
		System.out.println(setstr);
		
	}

}
