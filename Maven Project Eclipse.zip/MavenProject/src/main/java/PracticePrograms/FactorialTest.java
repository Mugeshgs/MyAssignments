package PracticePrograms;

public class FactorialTest {

	public static int getFactorial(int num) 
	{
					int fact=1;
			// Write your code here		
	    for(int i=1;i<=num;i++)
	    {
	      fact=fact*i;
	    System.out.println(fact);

	}
		return fact;
	    }
	public static void main(String[] args) {

getFactorial(5);
	}

}
