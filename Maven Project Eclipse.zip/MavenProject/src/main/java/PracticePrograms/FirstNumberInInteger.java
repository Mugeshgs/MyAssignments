package PracticePrograms;

public class FirstNumberInInteger {


	
	
	public static void main(String[] args) {

		int n=453;
		
		while(n>=10) 
		{
			n=n/10;
		}	
	System.out.println(n);	
	}

}
