package PracticePrograms;

public class ArrayElementsInEvenPosition {

	public static void main(String[] args) {
		
		int a[]= {1,13,3,4,5,6,7,8,9,10};
		
		for(int i=0;i<a.length;i+=2) {
			System.out.println(a[i]);
		}
		}

}
