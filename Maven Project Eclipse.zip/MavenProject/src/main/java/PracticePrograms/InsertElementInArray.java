package PracticePrograms;
import java.util.Arrays;

public class InsertElementInArray {

	public static void main(String[] args) {

		int [] arr= {1,2,3,4,5,6,7,8,9,10};
		int index=4;
		int num=50;
		
		System.out.println("Before Insertion:" + Arrays.toString(arr));
		
for(int i=arr.length-1;i>index;i--) 
{
			arr[i]=arr[i-1];
			
			
			
		}
arr[index]=num;
System.out.println("After Insertion:" + Arrays.toString(arr));

		
		
	}

}
