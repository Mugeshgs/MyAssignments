package PracticePrograms;

public class LearnOperators {
	
	public static void main(String args[]) {
		
/**	//FOR loop
		System.out.println("FOR LOOP");

		for(int i=1;i<=5;i++) {
			System.out.println(i);
			System.out.println("Mugesh");
		}
		
	//WHILE CONDITION
		System.out.println("WHILE LOOP");
		int rain=1;
		while(rain<=10) {
			System.out.println(rain);
			rain++;
		}
	
	//IF Condition - to check whether the number is +ve or -ve
		
		System.out.println("IF CONDITION");
		int j=0;
		
		if(j>0){
		
			System.out.println("Positive");}
			else if(j<0) 
			{
				System.out.println("Negative");
			}
			else 
			{
				System.out.println("Zero");
			}
		*/
		for(int k=1;k<=20;k++) {
			
			if(k%2!=0) {
				
				System.out.println(k + "Odd Number");
			}
		}
		
			
		}
	
	}
	


