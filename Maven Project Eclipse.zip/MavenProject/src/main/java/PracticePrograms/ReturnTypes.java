package PracticePrograms;

public class ReturnTypes {
	
	public String brandName() {
		
		String brand="Samsung";
		
		return brand;
		
	}
	
	public static void main(String args[]) {
		
		ReturnTypes r=new ReturnTypes();
		System.out.println(r.brandName());
		
		
	}

}
