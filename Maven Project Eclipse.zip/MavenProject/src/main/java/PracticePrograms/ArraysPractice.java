package PracticePrograms;

public class ArraysPractice {

	public static void main(String[] args) {

		int a[]= {1,2,3,4,5};
			
		for(int j=0;j<a.length;j++) 
		{
			
			System.out.println(a[j]);
		}
	
	
	
		
	}}

