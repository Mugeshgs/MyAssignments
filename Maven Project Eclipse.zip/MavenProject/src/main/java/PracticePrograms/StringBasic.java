package PracticePrograms;

public class StringBasic {

	public static void main(String[] args) {

		String a="I am Indian";
		
		System.out.println(a.charAt(0));
		System.out.println(a.hashCode());
		System.out.println(a.isBlank());
		System.out.println(a.replace("I am", "I'm an"));
		System.out.println(a.replaceAll("I am Indian", "No Name"));
		
		char[] ch= a.toCharArray(); 
		
		for(char c : ch) {
			System.out.print(c + "   ");
		}
	}

}