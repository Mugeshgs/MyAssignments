package PracticePrograms;

import org.openqa.selenium.firefox.FirefoxDriver;

public class LeafTaps {
	
	public static void main(String[] args) {
		FirefoxDriver driver=new FirefoxDriver(); 
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.manage().window().maximize();
		}

}