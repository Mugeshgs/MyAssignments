package PracticePrograms;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class ZohoAnalyticsLogin {

	public static void main(String[] args) {

	ChromeDriver driver=new ChromeDriver();
	
	driver.get("https://www.zoho.com/analytics/");
	
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	
	driver.findElement(By.className("zgh-login")).click();
	
	driver.findElement(By.id("login_id")).sendKeys("mugeshzohotesting@gmail.com");
	driver.findElement(By.id("nextbtn")).click();
	driver.findElement(By.id("password")).sendKeys("Chandramouli@13");
	driver.findElement(By.id("nextbtn")).click();
	
	//driver.findElement(By.partialLinkText("Remind")).click();
	
	driver.findElement(By.id("ZRHeaderOrg")).getText();
	String titletext= driver.findElement(By.id("ZRHeaderOrg")).getText();
	
	System.out.println(titletext);
	
	}

}
