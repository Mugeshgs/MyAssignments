package PracticePrograms;

public class SwapNumbers {

	public void Swap(int a,int b) {
		
		int temp;
		temp=a;
		a=b;
		b=temp;
		
		System.out.println(a + " "+ b);
		
	}
	
	public static int [] SwapDigits(int a,int b) {
		
		
		
		return null;
		
	}
	public static void main(String[] args) {

		SwapNumbers s=new SwapNumbers();
		
		s.Swap(1, 3);
		

	}

}
