package PracticePrograms;

public class Reverse {

	public static void main(String[] args) {

		String input="testleaf";
		
		char [] ch=input.toCharArray();
		
		for(int i=ch.length-1;i>=0;i--) {
			
			System.out.println(ch);
		
			
		}
		
	}

}
