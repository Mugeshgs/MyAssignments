package PracticePrograms;

public class ArmstrongNumber {
	
	
	
	public static boolean isArmStrong(long num) 
	
	{
		while(num>=10) {
			num=num/10;
			System.out.println(num);

		}
		
		return false;
		
	}

	public static void main(String[] args) {
	
		isArmStrong(153);

	}

}
