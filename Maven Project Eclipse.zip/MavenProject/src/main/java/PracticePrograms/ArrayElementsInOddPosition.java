package PracticePrograms;

public class ArrayElementsInOddPosition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
