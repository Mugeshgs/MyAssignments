package PracticePrograms;

public class LastNumberInInteger {
	
	public void LastDigit() {
		
		int n=453;
		int last=n%10;
		System.out.println(last);
		
	}

	public static void main(String[] args) {
LastNumberInInteger l=new LastNumberInInteger();
l.LastDigit();
	}

}
