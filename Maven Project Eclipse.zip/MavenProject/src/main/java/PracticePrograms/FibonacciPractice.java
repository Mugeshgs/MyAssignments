package PracticePrograms;

public class FibonacciPractice {

	public static void main(String[] args) {

		int num=10;
		int i=0,j=1;
		int temp;
		for(int k=1;k<=num;++k) {
		      System.out.print(i+ ", ");
			
			temp=i+j;
			i=j;
			j=temp;
				
			}
		
			
		}
		
	}


