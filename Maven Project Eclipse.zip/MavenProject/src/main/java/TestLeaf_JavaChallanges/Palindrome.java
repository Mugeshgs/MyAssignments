package TestLeaf_JavaChallanges;


/**A phrase is a palindrome if, after converting all uppercase letters into lowercase letters and removing all non-alphanumeric characters, 
it reads the same forward and backward. Alphanumeric characters include letters and numbers.*/

/**Input: s = "A man, a plan, a canal: Panama"
Output: true
Explanation: "amanaplanacanalpanama" is a palindrome.
*/

public class Palindrome {

	public static void main(String[] args) {

		
		String s="A man, a plan, a canal: Panama";
		String s2="";
		
		String lowerCase = s.toLowerCase();
	
	
		String nonalpha=lowerCase.replaceAll("[^a-zA-Z_0-9]", "");
		
		System.out.println("Non-alpha numeric: "+ nonalpha);
		
		char[] alpha=nonalpha.toCharArray();
		
	for(int i=alpha.length-1;i>=0;i--) {
		
s2=s2+alpha[i];

	}
		
		if(s2.equals(nonalpha)) {
			System.out.println("Palindrome");
		}
		else {
			System.out.println("Not a Palindrome");
		}
		
		
		
	}

}
