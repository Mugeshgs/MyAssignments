package TestLeaf_JavaChallanges;

//return the length of the last word in the string.

public class Challenge1 {

	public static void main(String[] args) {

		String s="Hello World";
		String s1="   fly me   to   the moon  ";
		String s1_trim = s1.trim();
		String s2="luffy is still joyboy";
		
		System.out.println((s.substring(s.lastIndexOf(" "))).trim());
		System.out.println((s1_trim.substring(s1_trim.lastIndexOf(" "))).trim());
		System.out.println((s2.substring(s2.lastIndexOf(" "))).trim());
		
		
	}

}
