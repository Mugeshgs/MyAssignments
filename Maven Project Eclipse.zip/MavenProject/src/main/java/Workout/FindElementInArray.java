package Workout;

public class FindElementInArray {

	public static void main(String[] args) {

		int input=20;
		
		int [] arr= {1,2,3,5,6,10,11,12,15};
		
		for(int i=0;i<arr.length;i++) {
			
			if(arr[i]==input) {
				System.out.println("The input is 10 and it is present in the Array");
			}
			else {
				System.out.println("The input is 20 and it is not present in the Array");

			}
		}
		
	}

}
