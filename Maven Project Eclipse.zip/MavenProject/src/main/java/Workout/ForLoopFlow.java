package Workout;

public class ForLoopFlow 

{

	public static void main(String[] args) 
{
		
for(int i=1;i<=3;i++)
{  
			System.out.println("Enter I");
	for(int j=1;j<=3;j++)
	{  
		System.out.println("Enter J");
		if(i==j) {
			
			System.out.println("Equal");
			
		}else {
			System.out.println("Exit J");
			break;
		}
		
	}//end of i  
}//end of j
		
}

}
