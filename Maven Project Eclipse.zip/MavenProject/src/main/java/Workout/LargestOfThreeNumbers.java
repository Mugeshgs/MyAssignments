package Workout;

public class LargestOfThreeNumbers {

	public static void main(String[] args) {

		int a=10,b=50,c=5;
		
		if(a>b) 
		{
			
			if(a>c) 
			{
				
				System.out.println("A is bigger");
			}
			
		}
		else if(b>c) 
		{
			System.out.println("B is bigger");
			
		}
		else {
			System.out.println("C is bigger");
		}
	}

}
