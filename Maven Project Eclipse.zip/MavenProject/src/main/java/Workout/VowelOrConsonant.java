package Workout;

public class VowelOrConsonant {
	
	public  void vowelOrConsonants(char y) {
		
		if(y=='a' || y=='e' || y=='i' || y=='o' || y=='u'){
			
			System.out.println("Its a Vowel");
		}
		else {
			System.out.println("Its a consonant");
		}
	}

	public static void main(String[] args) {
		VowelOrConsonant vc=new VowelOrConsonant();
		
		vc.vowelOrConsonants('a');
		vc.vowelOrConsonants('b');
		
		
	}

}
