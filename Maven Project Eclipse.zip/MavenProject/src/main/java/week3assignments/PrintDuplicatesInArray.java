package week3assignments;

public class PrintDuplicatesInArray {

	public static void main(String[] args) {

		int[] arr = {14,12,13,11,15,14,18,16,17,19,18,17,20};
		
		int n=arr.length;
		int count;
		
		for(int i=0;i<n;i++) {
			count=1;
			for(int j=i+1;j<n;j++) {
				
				if(arr[i]==arr[j]) {
					count++;
									}
				
				
			}
			if(count>1){
				
				System.out.println("Duplicate values in the array are: "+arr[i]);
				
			}
			
			
		}
		
		

		}
	}


