package org.college;

public class College {

	public void collegeName() {
		
		System.out.println("College Name: SASTRA UNIVERSITY");
		
	}
	
	public void collegeCode() {
		
		System.out.println("Code: SASTRA");
		
	}
	public void collegeRank() {
		System.out.println("Rank: 1st Rank");
		
	}
}
