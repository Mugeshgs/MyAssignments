package org.department;

import org.college.College;

public class Department extends College{
	
	public void deptName(){
		System.out.println("Department name: CSE");
		
	}

}
