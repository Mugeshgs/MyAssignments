package org.system;

public class Computer {
	
	public void computerModel() {
		System.out.println("Model is Macbook Pro");
	}

}
