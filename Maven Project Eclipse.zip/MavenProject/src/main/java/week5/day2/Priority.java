package week5.day2;

import org.testng.annotations.Test;

public class Priority {
@Test (priority=1)
	public void PrioritySample() {

	System.out.println("Priority");
	}

@Test (priority=-1)
public void PrioritySample1() {

	System.out.println("Priority1");
	}

}
