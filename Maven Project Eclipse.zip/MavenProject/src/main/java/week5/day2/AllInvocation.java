package week5.day2;

import org.testng.annotations.Test;

public class AllInvocation {
	
	@Test(invocationCount = 2,threadPoolSize = 2)

	public void create() {
		
	System.out.println("Create");
	
	}
		@Test(invocationCount = 3,invocationTimeOut = 3000)
	public void edit() {
		
		System.out.println("Edit");
		
		}
	
		@Test
	public void delete() {
		
		System.out.println("Delete");
		
		}


}
