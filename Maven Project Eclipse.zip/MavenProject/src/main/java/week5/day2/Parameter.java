package week5.day2;

public class Parameter {
	
	/**
	 * 
	 * Steps to implement parameter
===============================
1.Identify the data that need to be static in xml(url,username,password)
2.Add the parameter tag for each one the data in xml file
3.Map the parameter in the java class(projectspecificmethod) using @Parameters
Note:the name is casesensitive so exactly the name match in th xml
4.use that parameter inside the method using arguments
Note:sequence matter but the name of the arguments does not matter
5.Now,we can replace arguments with hard code of value
you should always run in xml becoz of parameter

public class ProjectSpecificMethod {
	public ChromeDriver driver;
	@Parameters({"url","username","password"})
	@BeforeMethod
	public void launchBrowser(String url,String uname, String pwd) {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.findElement(By.id("username")).sendKeys(uname);
		driver.findElement(By.id("password")).sendKeys(pwd);
		driver.findElement(By.className("decorativeSubmit")).click();
		driver.findElement(By.linkText("CRM/SFA")).click();
		driver.findElement(By.linkText("Leads")).click();
	}
	@AfterMethod
	public void tearDown() {
		driver.close();
	}
}

<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE suite SYSTEM "https://testng.org/testng-1.0.dtd">
<suite name="Suite">
<parameter name="url" value="http://leaftaps.com/opentaps/"></parameter>
<parameter name="username" value="DemoSalesManager"></parameter>
<parameter name="password" value="crmsfa"></parameter>
  <test thread-count="5" name="Test">
    <classes>
      <class name="week5.day2.CreateLead"/>
      <class name="week5.day2.EditLead"/>
      
    </classes>
  </test> <!-- Test -->
</suite> <!-- Suite -->


	 */

}
