package week5.day2;

import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

public class IgnoreTestCase {

	@Ignore
	@Test
	public void IgnoreTest() {
		
		System.out.println("Ignore this Method");

	}
	@Test(enabled=false)
	
public void IgnoreTest1() {
		
		System.out.println("Enabled set to False");

	}
	
	@Test (enabled=true)
public void IgnoreTest2() {
		
		System.out.println("Enabled set to True");

	}

}
