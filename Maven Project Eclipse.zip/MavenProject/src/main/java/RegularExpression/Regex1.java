package RegularExpression;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Regex1 {

	public static void main(String[] args) 
	{
		String s = "I am Mugesh from India and I'm an Indian";

		Pattern p = Pattern.compile("India");

		Matcher m = p.matcher(s);

		while (m.find()) {
			System.out.println(m.group());
		}
	}

}
