package RegularExpression;

public class RegExBasics {

	public static void main(String[] args) {

String sent="Zoho has more then 10,000 employees			in India";

//Get only the numbers from the text

String replaceAll = sent.replaceAll("\\D", "");
System.out.println(replaceAll);

//Get only the words except any other numbers or symbols

String replaceAll2 = sent.replaceAll("\\s", "");
System.out.println(replaceAll2);
	}

}
