package RegularExpression;

public class SingleChar {

	public static void main(String[] args) {
		// 
		
	}

}
