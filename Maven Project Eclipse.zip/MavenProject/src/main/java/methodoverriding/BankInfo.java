package methodoverriding;

public class BankInfo {
	
	public void saving() {
		System.out.println("Savings Account Details");
		
	}
	public void  fixed() {
		System.out.println("FD Interest Rate changed");
		
	}
	public void deposit() {
		
		System.out.println("Depost limit will be set by the Banks");
		
	}

}
