package week3.day1;

public class SamsungConcreteClass extends androidTV{
	
	public void openApp() {
		// TODO Auto-generated method stub
		
	}

	public void playVideo() {
		System.out.println("Video");
	}
	
	public static void main(String[] args) {
		
	}

	
	
}
