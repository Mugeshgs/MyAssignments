package week3.day1;

public class androidPhonePolymorphismOverriding extends smartPhonePolymorphismOverriding{
	
	public void takeVideo() {
		System.out.println("From Android Phone - Overriding");
	}
	
	public static void main(String [] args) {
		
		androidPhonePolymorphismOverriding android=new androidPhonePolymorphismOverriding();
		
		android.takeVideo();
	}
	

}
