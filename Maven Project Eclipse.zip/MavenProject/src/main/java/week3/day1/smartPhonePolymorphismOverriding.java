package week3.day1;

public class smartPhonePolymorphismOverriding {
	
	public void takeVideo() {
		System.out.println("From Smart Phone");
	}

}
