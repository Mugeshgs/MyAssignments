package week3.day1;

public interface AndroidInterface {
	
	public void openApp();
	public void playVideo();

}
