package week3.day1;

public class myPhoneInheritance{
	
	public static void main(String[] args) {
		
		iPhoneInheritance ip=new iPhoneInheritance();
		
		ip.makeCall();
		ip.sendSMS();
		ip.increaseVolume();
		ip.shutDown();
		ip.startAPP();
	}

}
