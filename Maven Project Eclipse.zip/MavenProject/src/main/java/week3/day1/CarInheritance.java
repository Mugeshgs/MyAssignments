package week3.day1;

public class CarInheritance extends VehicleInheritance{
	
	public void handSignal() {
		System.out.println("Coming from Car Hand Signal");
	}
	
public static void main (String [] args) {
	
	CarInheritance car=new CarInheritance();
	car.applyBrake();
	
	
}
}
