package week3.day1;

public class iPhoneInheritance extends iOSInheritance{
	public void makeCall() {
		
		System.out.println("makeCall coming from iPhone");
	}
	
	public void sendSMS() {
		
		System.out.println("sendSMS coming from iPhone");

		
	}

}
