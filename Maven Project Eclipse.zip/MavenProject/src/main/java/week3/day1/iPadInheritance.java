package week3.day1;

public class iPadInheritance extends iOSInheritance{
	
	public void watchMovie() {
		
		System.out.println("watchMovie coming from iPad");

		
	}

}
