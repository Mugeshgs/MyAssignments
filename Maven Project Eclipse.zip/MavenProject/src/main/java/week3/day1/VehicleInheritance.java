package week3.day1;

public class VehicleInheritance {

	public void applyBrake() {
		System.out.println("Coming from Vehicle Class");
	}
	
	}

