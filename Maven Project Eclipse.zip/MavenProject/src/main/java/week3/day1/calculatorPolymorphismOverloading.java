package week3.day1;

public class calculatorPolymorphismOverloading {
	
	public void add(int a, int b) {
		System.out.println(a+b);
		
	}
public void add(int a, int b, int c) {
	System.out.println(a+b+c);	
	}
	
public void mul(double a, double b) {
	System.out.println(a*b);
	
}

public void mul(float a, float b) {
	System.out.println(a*b);
	
}

	
	public static void main(String[] args) {
		
		calculatorPolymorphismOverloading calc=new calculatorPolymorphismOverloading();
		calc.add(10, 20);
		calc.add(10, 20, 40);
		calc.mul(5.55, 3.65);
		calc.mul(1.56f, 2.67f);
		
	}

}
