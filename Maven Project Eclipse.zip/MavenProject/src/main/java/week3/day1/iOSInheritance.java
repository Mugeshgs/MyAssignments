package week3.day1;

public class iOSInheritance {
	
	public void startAPP() {
		System.out.println("startAPP Coming from iOS");

	}
	
	public void increaseVolume() {
		
		System.out.println("increaseVolume Coming from iOS");
		
	}
	public void shutDown() {
		
		System.out.println("shutDown Coming from iOS");

		
	}

}
