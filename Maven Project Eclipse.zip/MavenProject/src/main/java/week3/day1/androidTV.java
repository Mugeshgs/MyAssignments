package week3.day1;

public abstract class androidTV implements AndroidInterface{
	
	public void openApp() {
		System.out.println("Open the App");
	}
	
	
	

}
