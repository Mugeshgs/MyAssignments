package week3.day1;

public class BMWInheritance extends CarInheritance{
	
	public void soundHorn() {
		System.out.println("Coming from BMW class");
	}

}
